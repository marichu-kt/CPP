
## EJECUCIÓN

- g++ -o main main.cpp -lssl -lcrypto -mconsole

- .\main.exe